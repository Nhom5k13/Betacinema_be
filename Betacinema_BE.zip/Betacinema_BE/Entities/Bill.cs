﻿namespace Betacinema_BE.Entities
{
    public class Bill : BaseEntity
    {
        public double? TotalMoney { set; get; }
        public string TradingCode { get; set; }
        public DateTime CreateTime { set; get; }
        public int CustomerId { set; get; }
        public string Name { set; get; }
        public DateTime UpdateTime { set; get; }
        public int? PromotionId { set; get; }
        public int BillStatusId { set; get; }
        public bool? IsActive { get; set; }
        public User? Customer { get; set; }
        public Promotion? Promotion { get; set; }
        public IEnumerable<BillFood>? BillFoods { get; set; }
        public IEnumerable<BillTicket>? BillTickets { get; set; }



    }
}
