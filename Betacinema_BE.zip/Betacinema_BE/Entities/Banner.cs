﻿namespace Betacinema_BE.Entities
{
    public class Banner :BaseEntity
    {
        public string ImageUrl { set; get; }

        public string Title { set; get; }
    }
}
