﻿namespace Betacinema_BE.Entities
{
    public class BillStatus :BaseEntity
    {
        public string Name { set; get; }
        public IEnumerable<Bill> Bills { get; set; }
    }
}
