﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataRequests.SeatRequests;
using Betacinema_BE.Payloads.DataResponses.RoomResponse;
using Betacinema_BE.Payloads.DataResponses.SeatResponse;
using Betacinema_BE.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Services.Implements
{
    public class SeatService : ISeatService
    {
        private readonly AppDbContext _context;
        private readonly ResponseObject<DataResponseSeat> _responseObject;
        private readonly SeatConverter _converter;

        public SeatService(AppDbContext context, ResponseObject<DataResponseSeat> responseObject, SeatConverter converter)
        {
            _context = context;
            _responseObject = responseObject;
            _converter = converter;
        }


        public async Task<ResponseObject<DataResponseSeat>> AddSeat(int userId, Request_AddSeat request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {
                    Seat seat = new Seat();
                    seat.Number = request.Number;
                    seat.Line = request.Line;
                    seat.SeatStatusId = request.SeatStatusId;
                    seat.RoomId = request.RoomId;
                    seat.SeatTypeId = request.SeatTypeId;
                    seat.IsActive = true;
                    await _context.seats.AddAsync(seat);
                    await _context.SaveChangesAsync();

                    return _responseObject.ResponseSuccess("Bạn đã thêm thành công", _converter.EntityToDTO(seat));

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }
            }
        }
        public async Task<ResponseObject<DataResponseSeat>> DeleteSeat(int userId, Request_DeleteSeat request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {

                    try
                    {
                        Seat seat = _context.seats.FirstOrDefault(m => m.Id == request.SeatId);
                        if (seat is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại", null);
                        }

                        else
                        {
                            if (seat.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Ghế đã được xóa", null);
                            }
                            else
                            {
                                seat.IsActive = false;
                                _context.seats.Update(seat);
                                _context.SaveChanges();
                                return _responseObject.ResponseSuccess("Bạn đã xóa thành công", _converter.EntityToDTO(seat));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }

            }
        }

        public async Task<PageResult<DataResponseSeat>> GetAllSeat(int pageSize, int pageNumber)
        {
            var query = _context.seats.Where(x => x.IsActive == true).Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query, pageSize, pageNumber);
            return result;
        }

        public async Task<ResponseObject<DataResponseSeat>> UpdateSeat(int userId, Request_UpdateSeat request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {

                    try
                    {
                        Seat seat = _context.seats.FirstOrDefault(m => m.Id == request.SeatId);
                        if (seat is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại", null);
                        }

                        else
                        {
                            if (seat.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Ghế đã được xóa", null);
                            }
                            else
                            {
                                if (!string.IsNullOrEmpty(request.Number.ToString()))
                                    seat.Number = (int)request.Number;

                                if (!string.IsNullOrEmpty(request.SeatStatusId.ToString()))
                                    seat.SeatStatusId = (int)request.SeatStatusId;

                                if (!string.IsNullOrEmpty(request.Line))
                                    seat.Line = request.Line;

                                if (!string.IsNullOrEmpty(request.RoomId.ToString()))
                                    seat.RoomId = (int)request.RoomId;

                                if (!string.IsNullOrEmpty(request.SeatTypeId.ToString()))
                                    seat.SeatTypeId = (int)request.SeatTypeId;


                                _context.seats.Update(seat);
                                _context.SaveChanges();
                                return _responseObject.ResponseSuccess("Bạn đã xóa thành công", _converter.EntityToDTO(seat));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }

            }
        }
    }
}
