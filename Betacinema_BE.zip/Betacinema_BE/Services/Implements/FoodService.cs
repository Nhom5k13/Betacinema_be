﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataRequests.FoodRequests;
using Betacinema_BE.Payloads.DataResponses.FoodResponse;
using Betacinema_BE.Services.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Services.Implements
{
    public class FoodService : IFoodService
    {

        private readonly AppDbContext _context;
        private readonly ResponseObject<DataResponseFood> _responseObject;
        private readonly FoodConverter _converter;

        public FoodService(AppDbContext context, ResponseObject<DataResponseFood> responseObject, FoodConverter converter)
        {
            _context = context;
            _responseObject = responseObject;
            _converter = converter;
        }

        public async Task<ResponseObject<DataResponseFood>> AddFood(int userId, Request_AddFood request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                Food food = new Food();
                food.NameOfFood = request.NameOfFood;
                food.Price = request.Price;
                food.Description = request.Description;
                food.Image = request.Image;
                food.IsActive = true;
                await _context.foods.AddAsync(food);
                await _context.SaveChangesAsync();

                return _responseObject.ResponseSuccess("Bạn đã thêm thành công", _converter.EntityToDTO(food));
            }
        }

        public async Task<ResponseObject<DataResponseFood>> DeleteFood(int userId, Request_DeleteFood request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {

                    try
                    {
                        Food food = _context.foods.FirstOrDefault(m => m.Id == request.FoodId);
                        if (food is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại", null);
                        }

                        else
                        {
                            if (food.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Food đã được xóa", null);
                            }
                            else
                            {
                                food.IsActive = false;
                                _context.foods.Update(food);
                                await  _context.AddRangeAsync();
                                return _responseObject.ResponseSuccess("Bạn đã xóa thành công", _converter.EntityToDTO(food));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }

            }
        }

        public async Task<PageResult<DataResponseFood>> GetAllFood(int pageSize, int pageNumber)
        {
            var query = _context.foods.Where(x => x.IsActive == true).Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query, pageSize, pageNumber);
            return result;
        }

        public Task<ICollection<BillFood>> OderFood(int userId, Request_OderFood request)
        {
            throw new NotImplementedException();
        }

        public async Task<ResponseObject<DataResponseFood>> UpdateFood(int userId, Request_UpdateFood request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {

                    try
                    {
                        Food food = _context.foods.FirstOrDefault(m => m.Id == request.FoodId);
                        if (food is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại", null);
                        }

                        else
                        {
                            if (food.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Food đã được xóa", null);
                            }
                            else
                            {

                                if (!string.IsNullOrEmpty(request.Price.ToString()))
                                    food.Price = (double)request.Price;

                                if (!string.IsNullOrEmpty(request.NameOfFood))
                                    food.NameOfFood = request.NameOfFood;

                                if (!string.IsNullOrEmpty(request.Description))
                                    food.Description = request.Description;

                                if (!string.IsNullOrEmpty(request.Image))
                                    food.Image = request.Image;

                                _context.foods.Update(food);
                                await _context.AddRangeAsync();
                                return _responseObject.ResponseSuccess("Bạn đã update thành công", _converter.EntityToDTO(food));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }

            }
        }
    }
}
