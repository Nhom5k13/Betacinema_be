﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataRequests.CinemaRequests;
using Betacinema_BE.Payloads.DataResponses.DataCinema;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;
using System.Drawing.Printing;

namespace Betacinema_BE.Services.Implements
{
    public class CinemaService : ICinemaService
    {
        private readonly AppDbContext _context;
        private readonly ResponseObject<DataResponseCinema> _responseObject;
        private readonly CinemaConverters _converter;

        public CinemaService(AppDbContext context, ResponseObject<DataResponseCinema> responseObject, CinemaConverters converter)
        {
            _context = context;
            _responseObject = responseObject;
            _converter = converter;
        }
        public async Task<PageResult<DataResponseCinema>> GetCinema(int pageSize, int pageNumber)
        {
            var query = _context.cinemas.Where(x => x.IsActive == true)
                        .Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query, pageSize, pageNumber);

            return result;
        }
        public async Task<ResponseObject<DataResponseCinema>> AddCinema(int userId, Request_AddCinema request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {
                    Cinema cinema = new Cinema();
                    cinema.NameOfCinema = request.NameOfCinema;
                    cinema.Address = request.Address;
                    cinema.Code = request.Code;
                    cinema.Description = request.Description;
                    cinema.IsActive = true;
                    await _context.cinemas.AddAsync(cinema);
                    await _context.SaveChangesAsync();

                    return _responseObject.ResponseSuccess("Bạn đã thêm thành công Rạp Phim", _converter.EntityToDTO(cinema));

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }


            }
        }

        public async Task<ResponseObject<DataResponseCinema>> DeleteCinema(int userId, Request_DeleteCinema request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {

                    try
                    {
                        Cinema cinema = _context.cinemas.FirstOrDefault(m => m.Id == request.CinemaId);
                        if (cinema is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại", null);
                        }

                        else
                        {
                            if (cinema.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Rạp Phim đã được xóa", null);
                            }
                            else
                            {
                                cinema.IsActive = false;
                                _context.cinemas.Update(cinema);
                                _context.SaveChanges();
                                return _responseObject.ResponseSuccess("Bạn đã xóa thành công Rạp Phim", _converter.EntityToDTO(cinema));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }

            }
        }

        public async Task<ResponseObject<DataResponseCinema>> UpdateCinema(int userId, Request_UpdateCinema request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {

                    try
                    {
                        Cinema cinema = _context.cinemas.FirstOrDefault(m => m.Id == request.CinemaId);
                        if (cinema is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại", null);
                        }

                        else
                        {
                            if (cinema.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Rạp Phim đã được xóa", null);
                            }
                            else
                            {

                                if (!string.IsNullOrEmpty(request.NameOfCinema))
                                    cinema.NameOfCinema = request.NameOfCinema;

                                if (!string.IsNullOrEmpty(request.Code))
                                    cinema.Code = request.Code;

                                if (!string.IsNullOrEmpty(request.Description))
                                    cinema.Description = request.Description;

                                if (!string.IsNullOrEmpty(request.Address))
                                    cinema.Address = request.Address;


                                _context.cinemas.Update(cinema);
                                _context.SaveChanges();
                                return _responseObject.ResponseSuccess("Bạn đã sửa thành công thông tin Rạp Phim", _converter.EntityToDTO(cinema));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }

            }
        }

        public async Task<PageResult<DataResponseCinema>> GetCinemaByMovie(int movieId, int pageSize, int pageNumber)
        {
            var query = _context.cinemas
           .Where(c => c.Rooms.Any(r => r.Schedules.Any(s => s.MovieId == movieId))).Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query,pageSize,pageNumber);
            return result;
        }

    }
}
