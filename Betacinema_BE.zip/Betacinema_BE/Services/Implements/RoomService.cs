﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataRequests.CinemaRequests;
using Betacinema_BE.Payloads.DataRequests.RoomRequests;
using Betacinema_BE.Payloads.DataResponses.DataCinema;
using Betacinema_BE.Payloads.DataResponses.RoomResponse;
using Betacinema_BE.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace Betacinema_BE.Services.Implements
{
    public class RoomService : IRoomService
    {
        private readonly AppDbContext _context;
        private readonly ResponseObject<DataResponseRoom> _responseObject;
        private readonly RoomConverter _converter;

        public RoomService(AppDbContext context, ResponseObject<DataResponseRoom> responseObject, RoomConverter converter)
        {
            _context = context;
            _responseObject = responseObject;
            _converter = converter;
        }
        public async Task<PageResult<DataResponseRoom>> GetAllRoom(int pageSize, int pageNumber)
        {
            var query = _context.rooms.Where(x => x.IsActive == true)
                        .Select(x => _converter.EntityToDTO(x));

            var result = Pagination.GetPagedData(query, pageSize, pageNumber);

            return result;
        }
        public async Task<ResponseObject<DataResponseRoom>> AddRoom(int userId, Request_AddRoom request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {
                    Room room = new Room();
                    room.Description = request.Description;
                    room.Capacity = request.Capacity;
                    room.Type = request.Type;
                    room.CinemaId = request.CinemaId;
                    room.Code = request.Code;
                    room.Name = request.Name;
                    room.IsActive = true;

                    await _context.rooms.AddAsync(room);
                    await _context.SaveChangesAsync();

                    return _responseObject.ResponseSuccess("Bạn đã thêm thành công", _converter.EntityToDTO(room));

                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }


            }
        }

        public async Task<ResponseObject<DataResponseRoom>> DeleteRoom(int userId, Request_DeleteRoom request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {
                    if (string.IsNullOrWhiteSpace(request.RoomId.ToString()))
                    {
                        return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Vui lòng điền đầy đủ thông tin", null);
                    }

                    else
                    {
                        try
                        {
                            Room room = _context.rooms.FirstOrDefault(m => m.Id == request.RoomId);
                            if (room is null)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại phòng", null);
                            }

                            else
                            {
                                if (room.IsActive == false)
                                {
                                    return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Phòng đã được xóa", null);
                                }
                                else
                                {
                                    room.IsActive = false;
                                    _context.rooms.Update(room);
                                    _context.SaveChanges();
                                    return _responseObject.ResponseSuccess("Bạn đã xóa thành công", _converter.EntityToDTO(room));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                        }
                    }


                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }


            }
        }

        public async Task<ResponseObject<DataResponseRoom>> UpdateRoom(int userId, Request_UpdateRoom request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {
                    if (string.IsNullOrWhiteSpace(request.RoomId.ToString()))
                    {
                        return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Vui lòng điền đầy đủ thông tin", null);
                    }

                    else
                    {
                        try
                        {
                            Room room = _context.rooms.FirstOrDefault(m => m.Id == request.RoomId);
                            if (room is null)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại phòng", null);
                            }

                            else
                            {
                                if (room.IsActive == false)
                                {
                                    return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Phòng đã được xóa", null);
                                }
                                else
                                {
                                    
                                    if (!string.IsNullOrEmpty(request.Capacity.ToString()))
                                        room.Capacity = (int)request.Capacity;

                                    if (!string.IsNullOrEmpty(request.Type.ToString()))
                                        room.Type = (int)request.Type;

                                    if (!string.IsNullOrEmpty(request.Description))
                                        room.Description = request.Description;

                                    if (!string.IsNullOrEmpty(request.CinemaId.ToString()))
                                        room.CinemaId = (int)request.CinemaId;

                                    if (!string.IsNullOrEmpty(request.Code))
                                        room.Code = request.Code;

                                    if (!string.IsNullOrEmpty(request.Name))
                                        room.Name = request.Name;

                                    _context.rooms.Update(room);
                                    _context.SaveChanges();
                                    return _responseObject.ResponseSuccess("Bạn đã update thành công", _converter.EntityToDTO(room));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                        }
                    }


                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }

            }
        }

        public async Task<PageResult<DataResponseRoom>> GetRoomByCinema(int cinemaId, int pageSize, int pageNumber)
        {

            var query = _context.rooms
                                 .Where(r => r.CinemaId == cinemaId).Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query, pageSize, pageNumber);
            return result;
        }
    }
}
