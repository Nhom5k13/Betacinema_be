﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataRequests.ScheduleRequests;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.ScheduleResponse;
using Betacinema_BE.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Drawing.Printing;

namespace Betacinema_BE.Services.Implements
{
    public class ScheduleService : IScheduleService
    {
        private readonly AppDbContext _context;
        private readonly ResponseObject<DataResponseSchedule> _responseObject;
        private readonly ScheduleConverter _converter;

        public ScheduleService(AppDbContext context, ResponseObject<DataResponseSchedule> responseObject, ScheduleConverter converter)
        {
            _context = context;
            _responseObject = responseObject;
            _converter = converter;

        }
        public async Task<ResponseObject<DataResponseSchedule>> AddSchedule(int userId, Request_AddSchedule request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                Schedule schedule = new Schedule();
                schedule.Price = request.Price;
                schedule.StartAt = request.StartAt;
                schedule.EndAt = request.EndAt;
                schedule.Code = request.Code;
                schedule.MovieId = request.MovieId;
                schedule.RoomId = request.RoomId;
                schedule.Name = request.Name;
                schedule.IsActive = true;

                var conflictingSchedules = _context.schedules
                                           .Where(s => s.RoomId == schedule.RoomId && s.IsActive == true && s.EndAt > schedule.StartAt && s.StartAt < schedule.EndAt);
                                                          
                if (conflictingSchedules.Any())
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Thời gian bị trùng", null);
                }
                await _context.schedules.AddAsync(schedule);
                await _context.SaveChangesAsync();

                return _responseObject.ResponseSuccess("Bạn đã thêm thành công", _converter.EntityToDTO(schedule));
            }
        }

        public async Task<ResponseObject<DataResponseSchedule>> DeleteSchedule(int userId, Request_DeleteSchedule request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {

                if (string.IsNullOrWhiteSpace(request.ScheduleId.ToString()))
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Vui lòng điền đầy đủ thông tin", null);
                }

                else
                {
                    try
                    {
                        Schedule schedule = _context.schedules.FirstOrDefault(m => m.Id == request.ScheduleId);
                        if (schedule is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại Schedule", null);
                        }

                        else
                        {
                            if (schedule.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "schedule đã được xóa", null);
                            }
                            else
                            {
                                schedule.IsActive = false;
                                _context.schedules.Update(schedule);
                                _context.SaveChanges();
                                return _responseObject.ResponseSuccess("Bạn đã xóa thành công", _converter.EntityToDTO(schedule));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }
                }

            }
        }

        public async Task<PageResult<DataResponseSchedule>> GetAllSchedule(int pageSize, int pageNumber)
        {
            var query = _context.schedules.Where(x => x.IsActive == true)
                        .Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query, pageSize, pageNumber);
            return result;
        }

        public async Task<PageResult<DataResponseSchedule>> GetScheduleByRoom(int roomId, int pageSize, int pageNumber)
        {
            var query = _context.schedules.Where(x => x.IsActive == true && x.RoomId == roomId)
                       .Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query, pageSize, pageNumber);
            return result;
        }

        public async Task<ResponseObject<DataResponseSchedule>> UpdateSchedule(int userId, Request_UpdateSchedule request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {

                if (string.IsNullOrWhiteSpace(request.ScheduleId.ToString()))
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Vui lòng điền đầy đủ thông tin", null);
                }

                else
                {
                    try
                    {
                        Schedule schedule = _context.schedules.FirstOrDefault(m => m.Id == request.ScheduleId);
                        if (schedule is null)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại Schedule", null);
                        }

                        else
                        {
                            if (schedule.IsActive == false)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "schedule đã được xóa", null);
                            }
                            else
                            {

                                if (!string.IsNullOrEmpty(request.Price.ToString()))
                                    schedule.Price = (double)request.Price;

                                if (!string.IsNullOrEmpty(request.StartAt.ToString()))
                                    schedule.StartAt = (DateTime)request.StartAt;

                                if (!string.IsNullOrEmpty(request.EndAt.ToString()))
                                    schedule.EndAt = (DateTime)request.EndAt;

                                if (!string.IsNullOrEmpty(request.MovieId.ToString()))
                                    schedule.MovieId = (int)request.MovieId;

                                if (!string.IsNullOrEmpty(request.RoomId.ToString()))
                                    schedule.RoomId = (int)request.RoomId;

                                if (!string.IsNullOrEmpty(request.Name))
                                    schedule.Name = request.Name;

                                if (!string.IsNullOrEmpty(request.Code))
                                    schedule.Code = request.Code;

                                var conflictingSchedules = _context.schedules
                                          .Where(s => s.RoomId == schedule.RoomId && s.IsActive == true && s.EndAt > schedule.StartAt && s.StartAt < schedule.EndAt);

                                if (conflictingSchedules.Any())
                                {
                                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Thời gian bị trùng", null);
                                }

                                _context.schedules.Update(schedule);
                                _context.SaveChanges();
                                return _responseObject.ResponseSuccess("Bạn đã xóa thành công", _converter.EntityToDTO(schedule));
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                    }
                }
            }
        }
    }
}
