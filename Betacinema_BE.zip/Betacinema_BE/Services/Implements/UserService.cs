﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataResponses.UserResponses;
using Betacinema_BE.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Betacinema_BE.Handler.HandlePagination;
using System.Drawing;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory.Database;

namespace Betacinema_BE.Services.Implements
{
    public class UserService : IUserService
    {
        private readonly AppDbContext _context;
        private readonly ResponseObject<DataResponseUser> _responseObject;
        private readonly UserConverter _converter;

        public UserService(AppDbContext context, ResponseObject<DataResponseUser> responseObject, UserConverter converter)
        {
            _context = context;
            _responseObject = responseObject;
            _converter = converter;

        }
        public async Task<PageResult<DataResponseUser>> GetAllUsers(int pageSize, int pageNumber)
        {

            var query = _context.users.Where(x => x.IsActive == true).Select(x => _converter.EntityToDTO(x));
            var result = Pagination.GetPagedData(query, pageSize, pageNumber);
            return result;
        }

        public async Task<ResponseObject<DataResponseUser>> GetUserById(int userId)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId);
            if (user is null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tìm thấy người dùng", null);
            }
            return _responseObject.ResponseSuccess("Lấy thông tin thành công", _converter.EntityToDTO(user));
        }
    }
}
