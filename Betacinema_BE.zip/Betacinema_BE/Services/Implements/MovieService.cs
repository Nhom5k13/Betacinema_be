﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.UserResponses;
using Betacinema_BE.Services.Interfaces;
using Microsoft.EntityFrameworkCore;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Payloads.DataRequests.MovieRequests;
using Betacinema_BE.Entities;
using Microsoft.IdentityModel.Tokens;

namespace Betacinema_BE.Services.Implements
{
    public class MovieService : IMovieService
    {
        private readonly AppDbContext _context;
        private readonly ResponseObject<DataResponseMovie> _responseObject;
        private readonly MovieConverter _converter;

        public MovieService(AppDbContext context, ResponseObject<DataResponseMovie> responseObject, MovieConverter converter)
        {
            _context = context;
            _responseObject = responseObject;
            _converter = converter;

        }
        #region Xem tất cả các movie (chưa sắp xếp)
        public async Task<PageResult<DataResponseMovie>> GetMovie(int pageSize, int pageNumber)
        {
            var query = _context.movies.Where(x => x.IsActive == true)
                        //.Include(m => m.Schedules).ThenInclude(s => s.Tickets)
                        //.OrderByDescending(m => m.Schedules.Sum(s => s.Tickets.Count()))
                        .Select(x => _converter.EntityToDTO(x));


            //var query = _context.movies.Where(x => x.IsActive == true)
            //                         .Select(x => new {
            //                                                Movie = x,
            //                                                TicketCount = x.Schedules.Sum(s => s.Tickets.Count())
            //                                            })
            //                        .OrderByDescending(x => x.TicketCount)
            //                        .Select(x => _converter.EntityToDTO(x.Movie));



            var result = Pagination.GetPagedData<DataResponseMovie>(query, pageSize, pageNumber);

            return result;
        }
        #endregion
        #region crud
        public async Task<ResponseObject<DataResponseMovie>> AddMovie(int userId, Request_AddMovie request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);
            
            if(user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            } 

            else
            {
                if(user.RoleId == 1 || user.RoleId == 2 )
                {
                        if (string.IsNullOrWhiteSpace(request.Name)
                          || string.IsNullOrWhiteSpace(request.Description)
                          || string.IsNullOrWhiteSpace(request.MovieDuration.ToString())
                          || string.IsNullOrWhiteSpace(request.PremiereDate.ToString())
                          || string.IsNullOrWhiteSpace(request.Director)
                          || string.IsNullOrWhiteSpace(request.EndTime.ToString())
                          || string.IsNullOrWhiteSpace(request.Image)
                          || string.IsNullOrWhiteSpace(request.Language)
                          || string.IsNullOrWhiteSpace(request.MovieTypeId.ToString())
                          || string.IsNullOrWhiteSpace(request.Trailer)
                          || string.IsNullOrWhiteSpace(request.HeroImage)
                          || string.IsNullOrWhiteSpace(request.RateId.ToString())
                  )
                        {
                            return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Vui lòng điền đầy đủ thông tin", null);
                        }
                        try
                        {
                            Movie movie = new Movie();
                            movie.Name = request.Name;
                            movie.Description = request.Description;
                            movie.MovieDuration = request.MovieDuration;
                            movie.PremiereDate = request.PremiereDate;
                            movie.Director = request.Director;
                            movie.EndTime = request.EndTime;
                            movie.Image = request.Image;
                            movie.Language = request.Language;
                            movie.MovieTypeId = request.MovieTypeId;
                            movie.Trailer = request.Trailer;
                            movie.HeroImage = request.HeroImage;
                            movie.RateId = request.RateId;
                            movie.IsActive = true;

                            await _context.movies.AddAsync(movie);
                            await _context.SaveChangesAsync();
                            return _responseObject.ResponseSuccess("Bạn đã thêm thành công một phim", _converter.EntityToDTO(movie));
                        }
                        catch (Exception ex)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                        }
                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }
            }

          


           
        }

        public async Task<ResponseObject<DataResponseMovie>> DeleteMovie(int userId, Request_DeleteMovie request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {
                    if(string.IsNullOrWhiteSpace(request.MovieId.ToString()))
                    {
                        return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Vui lòng điền đầy đủ thông tin", null);
                    }

                    else
                    {
                        try 
                        {
                            Movie movie = _context.movies.FirstOrDefault(m => m.Id == request.MovieId);
                            if(movie is null)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại phim", null);
                            }

                            else
                            {
                                if(movie.IsActive == false)
                                {
                                    return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Phim đã được xóa", null);
                                }
                                else
                                {
                                    movie.IsActive = false;
                                    _context.movies.Update(movie);
                                    _context.SaveChanges();
                                    return _responseObject.ResponseSuccess("Bạn đã xóa thành công", _converter.EntityToDTO(movie));
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                        }
                    }
                     
                    
                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }


            }
        }

        public async Task<ResponseObject<DataResponseMovie>> UpdateMovie(int userId, Request_UpdateMovie request)
        {
            var user = await _context.users.SingleOrDefaultAsync(x => x.Id == userId && x.IsActive == true);

            if (user == null)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại người dùng", null);
            }

            else
            {
                if (user.RoleId == 1 || user.RoleId == 2)
                {
                    if (string.IsNullOrWhiteSpace(request.MovieId.ToString()))
                    {
                        return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Vui lòng điền đầy đủ thông tin", null);
                    }

                    else
                    {
                        try
                        {
                            Movie movie = _context.movies.FirstOrDefault(m => m.Id == request.MovieId);
                            if (movie is null)
                            {
                                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tồn tại phim", null);
                            }

                            else
                            {
                                if (!string.IsNullOrEmpty(request.Name))
                                    movie.Name = request.Name;

                                if (!string.IsNullOrEmpty(request.MovieDuration.ToString()))
                                    movie.MovieDuration = (int)request.MovieDuration;

                                if (!string.IsNullOrEmpty(request.EndTime.ToString()))
                                    movie.EndTime = (DateTime)request.EndTime;

                                if (!string.IsNullOrEmpty(request.PremiereDate.ToString()))
                                    movie.PremiereDate = (DateTime)request.PremiereDate;

                                if (!string.IsNullOrEmpty(request.Description))
                                    movie.Description = request.Description;

                                if (!string.IsNullOrEmpty(request.Director))
                                    movie.Director = request.Director;

                                if (!string.IsNullOrEmpty(request.Image))
                                    movie.Image = request.Image;

                                if (!string.IsNullOrEmpty(request.HeroImage))
                                    movie.HeroImage = request.HeroImage;

                                if (!string.IsNullOrEmpty(request.Language))
                                    movie.Language = request.Language;

                                if (!string.IsNullOrEmpty(request.MovieTypeId.ToString()))
                                    movie.MovieTypeId = (int)request.MovieTypeId;

                                if (!string.IsNullOrEmpty(request.RateId.ToString()))
                                    movie.RateId = request.RateId;

                                if (!string.IsNullOrEmpty(request.Trailer))
                                    movie.Trailer = request.Trailer;

                                _context.Update(movie);
                                await _context.SaveChangesAsync();
                                return _responseObject.ResponseSuccess("Bạn đã sửa thành công", _converter.EntityToDTO(movie));

                            }
                        }
                        catch (Exception ex)
                        {
                            return _responseObject.ResponseError(StatusCodes.Status500InternalServerError, ex.Message, null);
                        }
                    }


                }

                else
                {
                    return _responseObject.ResponseError(StatusCodes.Status400BadRequest, "Bạn không có quyền này", null);
                }


            }
        }

        public async Task<ResponseObject<DataResponseMovie>> GetMovieById(int MovieId)
        {
            Movie movie = _context.movies.FirstOrDefault(m => m.Id == MovieId);
            if(movie is null || movie.IsActive == false)
            {
                return _responseObject.ResponseError(StatusCodes.Status404NotFound, "Không tìm thấy phim", null);
            }

            return _responseObject.ResponseSuccess("Get movie by Id: " + MovieId, _converter.EntityToDTO(movie));
        }



        #endregion
    }
}
