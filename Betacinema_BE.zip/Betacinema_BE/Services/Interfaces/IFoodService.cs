﻿using Betacinema_BE.Entities;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataRequests.FoodRequests;
using Betacinema_BE.Payloads.DataRequests.SeatRequests;
using Betacinema_BE.Payloads.DataResponses.FoodResponse;
using Betacinema_BE.Payloads.DataResponses.SeatResponse;

namespace Betacinema_BE.Services.Interfaces
{
    public interface IFoodService
    {
        Task<PageResult<DataResponseFood>> GetAllFood(int pageSize, int pageNumber);
        Task<ResponseObject<DataResponseFood>> AddFood(int userId, Request_AddFood request);
        Task<ResponseObject<DataResponseFood>> DeleteFood(int userId, Request_DeleteFood request);
        Task<ResponseObject<DataResponseFood>> UpdateFood(int userId, Request_UpdateFood request);
        Task<ICollection<BillFood>> OderFood(int userId, Request_OderFood request);
    }
}
