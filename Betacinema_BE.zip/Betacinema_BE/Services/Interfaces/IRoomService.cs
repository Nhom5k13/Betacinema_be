﻿using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataRequests.CinemaRequests;
using Betacinema_BE.Payloads.DataRequests.RoomRequests;
using Betacinema_BE.Payloads.DataResponses.DataCinema;
using Betacinema_BE.Payloads.DataResponses.RoomResponse;

namespace Betacinema_BE.Services.Interfaces
{
    public interface IRoomService
    {
        Task<PageResult<DataResponseRoom>> GetAllRoom(int pageSize, int pageNumber);
        Task<ResponseObject<DataResponseRoom>> AddRoom(int userId, Request_AddRoom request);
        Task<ResponseObject<DataResponseRoom>> DeleteRoom(int userId, Request_DeleteRoom request);
        Task<ResponseObject<DataResponseRoom>> UpdateRoom(int userId, Request_UpdateRoom request);
        Task<PageResult<DataResponseRoom>> GetRoomByCinema(int cinemaId,int pageSize, int pageNumber);
    }
}
