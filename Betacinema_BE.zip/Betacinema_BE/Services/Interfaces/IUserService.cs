﻿using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataResponses.UserResponses;
using Betacinema_BE.Handler.HandlePagination;

namespace Betacinema_BE.Services.Interfaces
{
    public interface IUserService
    {
        Task<PageResult<DataResponseUser>> GetAllUsers(int pageSize, int pageNumber);
        Task<ResponseObject<DataResponseUser>> GetUserById(int userId);
    }
}
