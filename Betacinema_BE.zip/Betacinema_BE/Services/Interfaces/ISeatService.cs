﻿using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataRequests.RoomRequests;
using Betacinema_BE.Payloads.DataRequests.SeatRequests;
using Betacinema_BE.Payloads.DataResponses.SeatResponse;

namespace Betacinema_BE.Services.Interfaces
{
    public interface ISeatService
    {
        Task<PageResult<DataResponseSeat>> GetAllSeat(int pageSize, int pageNumber);
        Task<ResponseObject<DataResponseSeat>> AddSeat(int userId, Request_AddSeat request);
        Task<ResponseObject<DataResponseSeat>> DeleteSeat(int userId, Request_DeleteSeat request);
        Task<ResponseObject<DataResponseSeat>> UpdateSeat(int userId, Request_UpdateSeat request);

       
    }
}
