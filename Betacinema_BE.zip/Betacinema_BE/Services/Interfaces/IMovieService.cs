﻿using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataRequests.UserRequest;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.UserResponses;
using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Payloads.DataRequests.MovieRequests;

namespace Betacinema_BE.Services.Interfaces
{
    public interface IMovieService
    {
        Task<PageResult<DataResponseMovie>> GetMovie(int pageSize, int pageNumber);
        Task<ResponseObject<DataResponseMovie>> AddMovie(int userId,Request_AddMovie request);
        Task<ResponseObject<DataResponseMovie>> DeleteMovie(int userId, Request_DeleteMovie request);
        Task<ResponseObject<DataResponseMovie>> UpdateMovie(int userId, Request_UpdateMovie request);
        Task<ResponseObject<DataResponseMovie>> GetMovieById( int MovieId);

       
    }
}
