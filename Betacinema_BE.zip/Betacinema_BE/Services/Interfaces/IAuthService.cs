﻿using Betacinema_BE.Entities;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataRequests.TokenRequests;
using Betacinema_BE.Payloads.DataRequests.UserRequest;
using Betacinema_BE.Payloads.DataRequests.UserRequests;
using Betacinema_BE.Payloads.DataResponses.UserResponses;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Services.Interfaces
{
    public interface IAuthService
    {
      
        Task<ResponseObject<DataResponseUser>> Register(Request_Register request);
        Task<ResponseObject<DataResponseUser>> ConfirmCreateNewAccount(Request_ConfirmCreateNewAccount request);
        Task<ResponseObject<DataResponseToken>> Login(Request_Login request);
        Task<ResponseObject<DataResponseUser>> ForgotPassword(Request_ForgotPassword request);
        Task<ResponseObject<DataResponseUser>> ConfirmCreateNewPassword(Request_ConfirmNewPassword request);
        ResponseObject<DataResponseToken> RenewAccessToken(Request_Token request);

    }
}
