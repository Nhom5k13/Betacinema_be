﻿using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataRequests.CinemaRequests;
using Betacinema_BE.Payloads.DataResponses.DataCinema;


namespace Betacinema_BE.Services.Interfaces
{
    public interface ICinemaService
    {
        Task<PageResult<DataResponseCinema>> GetCinema(int pageSize, int pageNumber);
        Task<ResponseObject<DataResponseCinema>> AddCinema(int userId, Request_AddCinema request);
        Task<ResponseObject<DataResponseCinema>> DeleteCinema(int userId, Request_DeleteCinema request);
        Task<ResponseObject<DataResponseCinema>> UpdateCinema(int userId, Request_UpdateCinema request);
        Task<PageResult<DataResponseCinema>> GetCinemaByMovie(int MovieId , int pageSize, int pageNumber);
    }
}
