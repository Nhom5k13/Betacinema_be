﻿using Betacinema_BE.Handler.HandlePagination;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.DataRequests.ScheduleRequests;
using Betacinema_BE.Payloads.DataRequests.SeatRequests;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.ScheduleResponse;


namespace Betacinema_BE.Services.Interfaces
{
    public interface IScheduleService
    {
        Task<PageResult<DataResponseSchedule>> GetAllSchedule(int pageSize, int pageNumber);
        Task<ResponseObject<DataResponseSchedule>> AddSchedule(int userId, Request_AddSchedule request);
        Task<ResponseObject<DataResponseSchedule>> DeleteSchedule(int userId, Request_DeleteSchedule request);
        Task<ResponseObject<DataResponseSchedule>> UpdateSchedule(int userId, Request_UpdateSchedule request);
        Task<PageResult<DataResponseSchedule>> GetScheduleByRoom(int roomId, int pageSize, int pageNumber);
    }
}
