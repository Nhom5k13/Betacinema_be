﻿using Betacinema_BE.Payloads.DataRequests.RoomRequests;
using Betacinema_BE.Payloads.DataRequests.SeatRequests;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SeatController : ControllerBase
    {
        private readonly ISeatService _seatService;

        public SeatController(ISeatService seatService)
        {
            _seatService = seatService;
        }


        [HttpGet("GetAllSeat")]
        public async Task<IActionResult> GetAllSeat(int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _seatService.GetAllSeat(pageSize, pageNumber));
        }

        [HttpPost("CreateSeat")]

        public async Task<IActionResult> CreateSeat(Request_AddSeat request, int userId)
        {
            var result = await _seatService.AddSeat(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
        [HttpDelete("DeleteSeat")]
        public async Task<IActionResult> DeleteSeat(Request_DeleteSeat request, int userId) //[FromForm]
        {
            var result = await _seatService.DeleteSeat(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPut("UpdateSeat")]
        public async Task<IActionResult> UpdateSeat([FromForm] Request_UpdateSeat request, int userId)
        {
            var result = await _seatService.UpdateSeat(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
    }
}
