﻿
using Betacinema_BE.Payloads.DataRequests.FoodRequests;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FoodController : ControllerBase
    {
        private readonly IFoodService _foodService;

        public FoodController(IFoodService foodService)
        {
            _foodService = foodService;
        }


        [HttpGet("GetAllFood")]
        public async Task<IActionResult> GetAllFood(int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _foodService.GetAllFood(pageSize, pageNumber));
        }

        [HttpPost("CreateFood")]
        [Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        [Authorize(Roles = "Admin, Manager")]
        public async Task<IActionResult> CreateFood(Request_AddFood request, int userId)
        {
            var result = await _foodService.AddFood(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpDelete("DeleteFood")]
        public async Task<IActionResult> DeleteFood(Request_DeleteFood request, int userId) //[FromForm]
        {
            var result = await _foodService.DeleteFood(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPut("UpdateFood")]
        public async Task<IActionResult> UpdateSFood([FromForm] Request_UpdateFood request, int userId)
        {
            var result = await _foodService.UpdateFood(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
    }
}
