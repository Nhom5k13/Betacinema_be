﻿using Betacinema_BE.Payloads.DataRequests.FoodRequests;
using Betacinema_BE.Payloads.DataRequests.ScheduleRequests;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ScheduleController : ControllerBase
    {
        private readonly IScheduleService _scheduleService;

        public ScheduleController(IScheduleService scheduleService)
        {
            _scheduleService = scheduleService;
        }


        [HttpGet("GetAllSchedule")]
        public async Task<IActionResult> GetAllSchedule(int pageSize = 10, int pageNumber = 1)
        {
      
            return Ok(await _scheduleService.GetAllSchedule(pageSize, pageNumber));
        }

        [HttpPost("CreateSchedule")]
        //[Authorize(AuthenticationSchemes = JwtBearerDefaults.AuthenticationScheme)]
        //[Authorize(Roles = "Admin, Manager")]
        public async Task<IActionResult> CreateSchedule(Request_AddSchedule request, int userId)
        {
            var result = await _scheduleService.AddSchedule(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpDelete("DeleteSchedule")]
        public async Task<IActionResult> DeleteSchedule(Request_DeleteSchedule request, int userId) //[FromForm]
        {
            var result = await _scheduleService.DeleteSchedule(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPut("UpdateSchedule")]
        public async Task<IActionResult> UpdateSFood([FromForm] Request_UpdateSchedule request, int userId)
        {
            var result = await _scheduleService.UpdateSchedule(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
    }
}
