﻿using Betacinema_BE.Payloads.DataRequests.CinemaRequests;
using Betacinema_BE.Payloads.DataRequests.MovieRequests;
using Betacinema_BE.Services.Implements;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CinemaController : ControllerBase
    {
        private readonly ICinemaService _cinemaService;

        public CinemaController(ICinemaService cinemaCinema)
        {
            _cinemaService = cinemaCinema;
        }

        [HttpGet("GetAllCinema")]
        public async Task<IActionResult> GetAllCinema(int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _cinemaService.GetCinema(pageSize, pageNumber));
        }

        [HttpPost("CreateCinema")]
        public async Task<IActionResult> CreateCinema(Request_AddCinema request, int userId) //[FromForm]
        {
            var result = await _cinemaService.AddCinema(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpDelete("DeleteCinema")]
        public async Task<IActionResult> DeleteCinema(Request_DeleteCinema request, int userId) //[FromForm]
        {
            var result = await _cinemaService.DeleteCinema(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPut("UpdateCinema")]
        public async Task<IActionResult> UpdateCinema([FromForm] Request_UpdateCinema request, int userId)
        {
            var result = await _cinemaService.UpdateCinema(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }


        [HttpGet("GetCinemaByMovie/{movieId}")]
        public async Task<IActionResult> GetCinemaByMovie(int movieId,int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _cinemaService.GetCinemaByMovie(movieId, pageSize, pageNumber));
        }
    }
}
