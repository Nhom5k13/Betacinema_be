﻿using Betacinema_BE.Payloads.DataRequests.MovieRequests;
using Betacinema_BE.Payloads.DataRequests.RoomRequests;
using Betacinema_BE.Services.Implements;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RoomController : ControllerBase
    {
        private readonly IRoomService _roomService;

        public RoomController(IRoomService roomService)
        {
            _roomService = roomService;
        }

        [HttpGet("GetAllRoom")]
        public async Task<IActionResult> GetAllRoom(int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _roomService.GetAllRoom(pageSize, pageNumber));
        }
        [HttpPost("CreateRoom")]

        public async Task<IActionResult> CreateRoom(Request_AddRoom request, int userId)
        {
            var result = await _roomService.AddRoom(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
        [HttpDelete("DeleteRoom")]
        public async Task<IActionResult> DeleteRoom(Request_DeleteRoom request, int userId) //[FromForm]
        {
            var result = await _roomService.DeleteRoom(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPut("UpdateRoom")]
        public async Task<IActionResult> UpdateRoom([FromForm] Request_UpdateRoom request, int userId)
        {
            var result = await _roomService.UpdateRoom(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

    }
}

