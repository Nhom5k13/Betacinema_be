﻿using Betacinema_BE.Services.Implements;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookTicketController : ControllerBase
    {
        private readonly IMovieService _movieService;
        private readonly ICinemaService _cinemaService;
        private readonly IRoomService _roomService;
        private readonly IScheduleService _scheduleService;

        public BookTicketController(IMovieService movieService, ICinemaService cinemaCinema, IRoomService roomService, IScheduleService scheduleService)
        {
            _movieService = movieService;
            _cinemaService = cinemaCinema;
            _roomService = roomService;
            _scheduleService = scheduleService;
        }

        [HttpGet("GetMovieById/{MovieId}")]
        public async Task<IActionResult> GetMovieById(int MovieId)
        {
            return Ok(await _movieService.GetMovieById(MovieId));
        }


        [HttpGet("GetCinemaByMovie/{movieId}")]
        public async Task<IActionResult> GetCinemaByMovie(int movieId, int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _cinemaService.GetCinemaByMovie(movieId, pageSize, pageNumber));
        }

        [HttpGet("GetRoomByCinema/{cinemaId}")]
        public async Task<IActionResult> GetRoomByCinema(int cinemaId, int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _roomService.GetRoomByCinema(cinemaId, pageSize, pageNumber));
        }

        [HttpGet("GetScheduleByRoom/{roomId}")]
        public async Task<IActionResult> GetScheduleByRoom(int roomId, int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _scheduleService.GetScheduleByRoom(roomId, pageSize, pageNumber));
        }


    }
}
