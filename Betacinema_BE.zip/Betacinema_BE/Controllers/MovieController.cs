﻿using Betacinema_BE.Payloads.DataRequests.MovieRequests;
using Betacinema_BE.Payloads.DataRequests.UserRequest;
using Betacinema_BE.Services.Implements;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MovieController : ControllerBase
    {
        private readonly IMovieService _movieService;

        public MovieController(IMovieService movieService)
        {
            _movieService = movieService;
        }

        [HttpGet("GetAllMovie")]
        public async Task<IActionResult> GetAllMovie(int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _movieService.GetMovie(pageSize, pageNumber));
        }

        [HttpGet("GetMovieById/{MovieId}")]
        public async Task<IActionResult> GetMovieById(int MovieId)
        {
            return Ok(await _movieService.GetMovieById(MovieId));
        }

        [HttpPost("CreateMovie")]
        public async Task<IActionResult> CreateMovie( Request_AddMovie request, int userId) //[FromForm]
        {
            var result = await _movieService.AddMovie(userId ,request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
        [HttpDelete("DeleteMovie")]
        public async Task<IActionResult> DeleteMovie(Request_DeleteMovie request, int userId) //[FromForm]
        {
            var result = await _movieService.DeleteMovie(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPut("UpdateMovie")]
        public async Task<IActionResult> UpdateMovie([FromForm] Request_UpdateMovie request, int userId) 
        {
            var result = await _movieService.UpdateMovie(userId, request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

    }
}
