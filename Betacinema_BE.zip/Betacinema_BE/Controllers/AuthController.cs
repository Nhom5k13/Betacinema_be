﻿using Azure.Core;
using Betacinema_BE.DataContext;
using Betacinema_BE.Payloads.DataRequests.TokenRequests;
using Betacinema_BE.Payloads.DataRequests.UserRequest;
using Betacinema_BE.Payloads.DataRequests.UserRequests;
using Betacinema_BE.Services.Implements;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        
        public AuthController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register(Request_Register request)
        {
            var result = await _authService.Register(request);

            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
        [HttpPost("ConfirmCreateNewAccount")]
        public async Task<IActionResult> ConfirmCreateNewAccount(Request_ConfirmCreateNewAccount request)
        {
            var result = await _authService.ConfirmCreateNewAccount(request);
            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }
      
        [HttpPost("Login")]
        public async Task<IActionResult> Login(Request_Login request)
        {
            var result = await _authService.Login(request);
            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPost("RenewAccessToken")]
        public IActionResult RenewAccessToken(Request_Token request)
        {
            var result = _authService.RenewAccessToken(request);
            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPost("ForgotPassword")]
        public async Task<IActionResult> ForgotPassword(Request_ForgotPassword request)
        {
            var result = await _authService.ForgotPassword(request);
            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        [HttpPost("ConfirmCreateNewPassword")]
        public async Task<IActionResult> ConfirmCreateNewPassword(Request_ConfirmNewPassword request)
        {
            var result = await _authService.ConfirmCreateNewPassword(request);
            switch (result.Status)
            {
                case 200:
                    return Ok(result);
                case 404:
                    return NotFound(result);
                case 400:
                    return BadRequest(result);
                case 403:
                    return Unauthorized(result);
                default:
                    return StatusCode(500, result);
            }
        }

        


    }
}
