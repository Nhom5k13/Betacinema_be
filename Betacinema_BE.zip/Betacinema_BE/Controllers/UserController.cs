﻿using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Betacinema_BE.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            _userService = userService;
        }

        [HttpGet("GetAllUsers")]
        //[Authorize(Roles = "Admin")]
        //[Authorize]
        public async Task<IActionResult> GetAllUsers(int pageSize = 10, int pageNumber = 1)
        {
            return Ok(await _userService.GetAllUsers(pageSize, pageNumber));
        }

        [HttpGet("GetUserById/{userId}")]
        public async Task<IActionResult> GetUserById(int userId)
        {
            return Ok(await _userService.GetUserById(userId));
        }

    }
}
