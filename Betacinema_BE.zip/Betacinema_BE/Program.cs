﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Handler.Responses;
using Betacinema_BE.Payloads.Converters;
using Betacinema_BE.Payloads.DataResponses.DataCinema;
using Betacinema_BE.Payloads.DataResponses.FoodResponse;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.RoomResponse;
using Betacinema_BE.Payloads.DataResponses.ScheduleResponse;
using Betacinema_BE.Payloads.DataResponses.SeatResponse;
using Betacinema_BE.Payloads.DataResponses.UserResponses;
using Betacinema_BE.Services.Implements;
using Betacinema_BE.Services.Interfaces;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using Microsoft.VisualBasic;
using Project_Pinterest.Constants;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen(option =>
//{
//    option.SwaggerDoc("v1", new OpenApiInfo { Title = "NS.Core API", Version = "v1" });
//    option.CustomSchemaIds(type => type.ToString());
//    option.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
//    {
//        In = ParameterLocation.Header,
//        Description = "Please enter a valid token",
//        Name = "Authorization",
//        Type = SecuritySchemeType.Http,
//        BearerFormat = "JWT",
//        Scheme = "Bearer"
//    });
//    option.AddSecurityRequirement(new OpenApiSecurityRequirement
//    {
//        {
//            new OpenApiSecurityScheme
//            {
//                Reference = new OpenApiReference
//                {
//                    Type=ReferenceType.SecurityScheme,
//                    Id="Bearer"
//                }
//            },
//            new string[]{}
//        }
//    });
//});
builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<AppDbContext>(opt => opt.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<ResponseObject<DataResponseUser>>();
builder.Services.AddScoped<IUserService, UserService>();
builder.Services.AddScoped<UserConverter>();
builder.Services.AddScoped<ResponseObject<DataResponseToken>>();
builder.Services.AddScoped<ResponseObject<DataResponseMovie>>();
builder.Services.AddScoped<IMovieService, MovieService>();
builder.Services.AddScoped<MovieConverter>();

builder.Services.AddScoped<ICinemaService, CinemaService>();
builder.Services.AddScoped<ResponseObject<DataResponseCinema>>();
builder.Services.AddScoped<CinemaConverters>();

builder.Services.AddScoped<IRoomService, RoomService>();
builder.Services.AddScoped<ResponseObject<DataResponseRoom>>();
builder.Services.AddScoped<RoomConverter>();

builder.Services.AddScoped<ISeatService, SeatService>();
builder.Services.AddScoped<ResponseObject<DataResponseSeat>>();
builder.Services.AddScoped<SeatConverter>();

builder.Services.AddScoped<IFoodService, FoodService>();
builder.Services.AddScoped<ResponseObject< DataResponseFood >> ();
builder.Services.AddScoped<FoodConverter>();

builder.Services.AddScoped<IScheduleService, ScheduleService>();
builder.Services.AddScoped<ResponseObject<DataResponseSchedule>>();
builder.Services.AddScoped<ScheduleConverter>();


builder.Services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme).AddJwtBearer(options =>
{
    options.RequireHttpsMetadata = false;
    options.SaveToken = true;
    options.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuerSigningKey = true,
        ValidateAudience = false,
        ValidateIssuer = false,
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
        builder.Configuration.GetSection(AppSettingsKeys.AUTH_SECRET).Value!))
    };
});
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAllOrigins", builder =>
    {
        builder.AllowAnyOrigin()
               .AllowAnyHeader()
               .AllowAnyMethod();
    });
});


//builder.Services.AddAuthentication(options =>
//{
//    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
//    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
//})
//    .AddJwtBearer(options =>
//    {
//        options.TokenValidationParameters = new TokenValidationParameters
//        {
//            ValidateIssuerSigningKey = true,
//            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
//        builder.Configuration.GetSection(AppSettingsKeys.AUTH_SECRET).Value!)),
//            ValidateIssuer = false,
//            ValidateAudience = false,
//            RequireExpirationTime = false,
//            ValidateLifetime = true
//        };
//    });



var app = builder.Build();
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.UseAuthentication();


app.MapControllers();

app.Run();
