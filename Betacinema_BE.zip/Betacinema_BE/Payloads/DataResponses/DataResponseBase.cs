﻿namespace Project_Pinterest.Payloads.DataResponses
{
    public class DataResponseBase
    {
        public int Id { get; set; }
    }
}
