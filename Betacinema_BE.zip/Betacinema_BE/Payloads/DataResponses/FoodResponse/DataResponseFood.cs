﻿namespace Betacinema_BE.Payloads.DataResponses.FoodResponse
{
    public class DataResponseFood
    {
        public double Price { get; set; }
        public string Description { get; set; }
        public string Image { get; set; }
        public string NameOfFood { get; set; }
    }
}
