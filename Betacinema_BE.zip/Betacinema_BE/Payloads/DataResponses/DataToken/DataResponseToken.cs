﻿
namespace Betacinema_BE.Payloads.DataResponses.UserResponses
{
    public class DataResponseToken
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
        public DataResponseUser DataResponseUser { get; set; }
    }
}
