﻿namespace Betacinema_BE.Payloads.DataResponses.SeatResponse
{
    public class DataResponseSeat
    {
        public int Number { get; set; }
        public int SeatStatusId { get; set; }
        public string Line { get; set; }
        public int RoomId { get; set; }
        public int SeatTypeId { get; set; }
    }
}
