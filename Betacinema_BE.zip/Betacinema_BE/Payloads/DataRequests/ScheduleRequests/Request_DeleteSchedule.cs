﻿namespace Betacinema_BE.Payloads.DataRequests.ScheduleRequests
{
    public class Request_DeleteSchedule
    {
        public int ScheduleId { get; set; }
    }
}
