﻿namespace Betacinema_BE.Payloads.DataRequests.UserRequests
{
    public class Request_ConfirmNewPassword
    {
        public string ConfirmCode { get; set; }
        public string NewPassword { get; set; }
        
    }
}
