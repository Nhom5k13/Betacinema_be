﻿namespace Betacinema_BE.Payloads.DataRequests.UserRequest
{
    public class Request_Register
    {
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
       
    }
}
