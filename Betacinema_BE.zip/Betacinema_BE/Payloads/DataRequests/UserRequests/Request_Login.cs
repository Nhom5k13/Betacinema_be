﻿namespace Betacinema_BE.Payloads.DataRequests.UserRequests
{
    public class Request_Login
    {
        public string UserName { get; set; }
        public string Password { get; set; }
    }
}
