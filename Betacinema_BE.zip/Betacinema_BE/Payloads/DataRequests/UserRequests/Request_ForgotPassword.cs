﻿namespace Betacinema_BE.Payloads.DataRequests.UserRequests
{
    public class Request_ForgotPassword
    {
        public string Email { get; set; }
    }
}
