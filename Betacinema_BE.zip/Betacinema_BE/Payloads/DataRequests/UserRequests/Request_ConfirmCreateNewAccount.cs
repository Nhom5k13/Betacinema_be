﻿namespace Betacinema_BE.Payloads.DataRequests.UserRequests
{
    public class Request_ConfirmCreateNewAccount
    {
        public string ConfirmCode { get; set; }
    }
}
