﻿namespace Betacinema_BE.Payloads.DataRequests.CinemaRequests
{
    public class Request_DeleteCinema
    {
        public int CinemaId { get; set; }
    }
}
