﻿namespace Betacinema_BE.Payloads.DataRequests.RoomRequests
{
    public class Request_DeleteRoom
    {
        public int RoomId { get; set; }
       // public int CinemaId { get; set;}
    }
}
