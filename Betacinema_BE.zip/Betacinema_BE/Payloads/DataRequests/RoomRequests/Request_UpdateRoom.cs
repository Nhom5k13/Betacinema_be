﻿namespace Betacinema_BE.Payloads.DataRequests.RoomRequests
{
    public class Request_UpdateRoom
    {
        public int RoomId { get; set; }
        public int? Capacity { get; set; }
        public int? Type { get; set; }
        public string? Description { get; set; }
        public int? CinemaId { get; set; }
        public string? Code { get; set; }
        public string? Name { get; set; }
    }
}
