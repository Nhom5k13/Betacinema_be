﻿namespace Betacinema_BE.Payloads.DataRequests.FoodRequests
{
    public class Request_DeleteFood
    {
        public int FoodId { get; set; }
    }
}
