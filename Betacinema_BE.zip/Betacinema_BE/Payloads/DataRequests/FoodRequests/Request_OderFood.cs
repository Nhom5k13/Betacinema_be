﻿namespace Betacinema_BE.Payloads.DataRequests.FoodRequests
{
    public class Request_OderFood
    {
        public IEnumerable<Request_FoodItem> OderFood { get; set; }
    }
}
