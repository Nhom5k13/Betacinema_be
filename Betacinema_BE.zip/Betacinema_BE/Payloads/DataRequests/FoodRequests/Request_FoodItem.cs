﻿namespace Betacinema_BE.Payloads.DataRequests.FoodRequests
{
    public class Request_FoodItem
    {   

        public int Quantity { get; set; }
        public int FoodId { get; set; }

    }
}
