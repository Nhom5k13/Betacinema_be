﻿namespace Betacinema_BE.Payloads.DataRequests.SeatRequests
{
    public class Request_DeleteSeat
    {
        public int SeatId { get; set; }
    }
}
