﻿namespace Betacinema_BE.Payloads.DataRequests.TokenRequests
{
    public class Request_Token
    {
        public string AccessToken { get; set; }
        public string RefreshToken { get; set; }
    }
}
