﻿namespace Betacinema_BE.Payloads.DataRequests.MovieRequests
{
    public class Request_DeleteMovie
    {
       public  int MovieId { get; set; }
      // public string? Name { get; set; }
    }
}
