﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Payloads.DataResponses.ScheduleResponse;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Payloads.Converters
{
    public class ScheduleConverter
    {
        private readonly AppDbContext _context;
        public ScheduleConverter(AppDbContext context)
        {
            _context = context;
        }

        public DataResponseSchedule EntityToDTO(Schedule schedule)
        {
            if (schedule == null || schedule.Id == null)
            {
                throw new ArgumentNullException("schedule is null or schedule.Id is null");
            }

            var scheduleItem = _context.schedules
                              .AsNoTracking()
                              .FirstOrDefault(x => x.Id == schedule.Id);



            if (scheduleItem == null)
            {
                return null;
            }

            return new DataResponseSchedule
            {
                Price = schedule.Price,
                StartAt = schedule.StartAt,
                EndAt = schedule.EndAt,
                Code = schedule.Code,
                MovieId = schedule.MovieId,
                Name = schedule.Name,
                RoomId = schedule.RoomId

            };
        }
    }
}