﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Payloads.DataResponses.DataCinema;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Payloads.Converters
{
    public class CinemaConverters
    {
        private readonly AppDbContext _context;
        public CinemaConverters(AppDbContext context)
        {
            _context = context;
        }

        public DataResponseCinema EntityToDTO(Cinema cinema)
        {
            if (cinema == null || cinema.Id == null)
            {
                throw new ArgumentNullException("cinema is null or cinema.Id is null");
            }

            var cinemaItem = _context.cinemas.AsNoTracking()
                                             .FirstOrDefault(x => x.Id == cinema.Id);

            if (cinemaItem == null)
            {
                return null;
            }

            return new DataResponseCinema
            {
                Address = cinema.Address,
                Description = cinema.Description,
                Code = cinema.Code,
                NameOfCinema = cinema.NameOfCinema

            };

        }
    }
}
