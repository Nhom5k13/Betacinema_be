﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.UserResponses;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Payloads.Converters
{
    public class MovieConverter
    {
        private readonly AppDbContext _context;
        public MovieConverter(AppDbContext context)
        {
            _context = context;
        }

        public DataResponseMovie EntityToDTO(Movie movie)
        {
            if (movie == null || movie.Id == null)
            {
                throw new ArgumentNullException("movie is null or movie.Id is null");
            }

            var movieItem = _context.movies.Include(m => m.Rate).Include(m => m.MovieType)
                                             .AsNoTracking()
                                             .FirstOrDefault(x => x.Id == movie.Id);

            

            if (movieItem == null)
            {
                return null;
            }

            return new DataResponseMovie
            {
                MovieDuration = movieItem.MovieDuration,
                EndTime = movieItem.EndTime,
                PremiereDate = movieItem.PremiereDate,
                Description = movieItem.Description,
                Director = movieItem.Director,
                Image = movieItem.Image,
                HeroImage = movieItem.HeroImage,
                Language = movieItem.Language,
                MovieType = movieItem.MovieType?.MovieTypeName,
                Name = movieItem.Name,
                Rate = movieItem.Rate?.Description,
                Trailer = movieItem.Trailer

            };

        }
    }

}
   

