﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.RoomResponse;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Payloads.Converters
{
    public class RoomConverter
    {
        private readonly AppDbContext _context;
        public RoomConverter(AppDbContext context)
        {
            _context = context;
        }

        public DataResponseRoom EntityToDTO(Room room)
        {
            if (room == null || room.Id == null)
            {
                throw new ArgumentNullException("room is null or room.Id is null");
            }

            var roomItem = _context.rooms
                              .AsNoTracking()
                              .FirstOrDefault(x => x.Id == room.Id);



            if (roomItem == null)
            {
                return null;
            }

            return new DataResponseRoom
            {
                Capacity = roomItem.Capacity,
                Type = roomItem.Type,
                Description = roomItem.Description,
                CinemaId = roomItem.CinemaId,
                Code = roomItem.Code,
                Name = roomItem.Name

            };

        }
    }
}
