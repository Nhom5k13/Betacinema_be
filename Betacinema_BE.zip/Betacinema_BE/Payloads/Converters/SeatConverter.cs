﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Payloads.DataResponses.MovieResponse;
using Betacinema_BE.Payloads.DataResponses.SeatResponse;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Payloads.Converters
{
    public class SeatConverter
    {
        private readonly AppDbContext _context;
        public SeatConverter(AppDbContext context)
        {
            _context = context;
        }

        public DataResponseSeat EntityToDTO(Seat seat)
        {
            if (seat == null || seat.Id == null)
            {
                throw new ArgumentNullException("seat is null or seat.Id is null");
            }

            var seatItem = _context.seats
                                             .AsNoTracking()
                                             .FirstOrDefault(x => x.Id == seat.Id);

            if (seatItem == null)
            {
                return null;
            }

            return new DataResponseSeat
            {
                Number = seatItem.Number,
                SeatStatusId = seatItem.SeatStatusId,
                Line = seatItem.Line,
                RoomId = seatItem.RoomId,
                SeatTypeId = seatItem.SeatTypeId

            };

        }
    }
}

