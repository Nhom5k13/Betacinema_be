﻿using Betacinema_BE.DataContext;
using Betacinema_BE.Entities;
using Betacinema_BE.Payloads.DataResponses.FoodResponse;
using Betacinema_BE.Payloads.DataResponses.SeatResponse;
using Microsoft.EntityFrameworkCore;

namespace Betacinema_BE.Payloads.Converters
{
    public class FoodConverter
    {
        private readonly AppDbContext _context;
        public FoodConverter(AppDbContext context)
        {
            _context = context;
        }

        public DataResponseFood EntityToDTO(Food food)
        {
            if (food == null || food.Id == null)
            {
                throw new ArgumentNullException("food is null or food.Id is null");
            }

            var foodItem = _context.foods.AsNoTracking()
                                         .FirstOrDefault(x => x.Id == food.Id);

            if (foodItem == null)
            {
                return null;
            }

            return new DataResponseFood
            {
                Price = foodItem.Price,
                Description = foodItem.Description,
                Image = foodItem.Image,
                NameOfFood = foodItem.NameOfFood
            };

        }
    }
}
