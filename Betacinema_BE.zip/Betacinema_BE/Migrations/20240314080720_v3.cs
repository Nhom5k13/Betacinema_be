﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Betacinema_BE.Migrations
{
    /// <inheritdoc />
    public partial class v3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_seats_seatStatuses_SeatStatusId",
                table: "seats");

            migrationBuilder.DropColumn(
                name: "SeatSatusId",
                table: "seats");

            migrationBuilder.AlterColumn<int>(
                name: "SeatStatusId",
                table: "seats",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AlterColumn<bool>(
                name: "IsActive",
                table: "promotions",
                type: "bit",
                nullable: true,
                oldClrType: typeof(bool),
                oldType: "bit");

            migrationBuilder.AddForeignKey(
                name: "FK_seats_seatStatuses_SeatStatusId",
                table: "seats",
                column: "SeatStatusId",
                principalTable: "seatStatuses",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_seats_seatStatuses_SeatStatusId",
                table: "seats");

            migrationBuilder.AlterColumn<int>(
                name: "SeatStatusId",
                table: "seats",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "SeatSatusId",
                table: "seats",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<bool>(
                name: "IsActive",
                table: "promotions",
                type: "bit",
                nullable: false,
                defaultValue: false,
                oldClrType: typeof(bool),
                oldType: "bit",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_seats_seatStatuses_SeatStatusId",
                table: "seats",
                column: "SeatStatusId",
                principalTable: "seatStatuses",
                principalColumn: "Id");
        }
    }
}
