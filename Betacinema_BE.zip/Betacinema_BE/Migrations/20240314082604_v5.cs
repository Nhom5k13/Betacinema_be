﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Betacinema_BE.Migrations
{
    /// <inheritdoc />
    public partial class v5 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_promotions_rankCustomer_RankCustomerId",
                table: "promotions");

            migrationBuilder.DropColumn(
                name: "RankCustomerld",
                table: "promotions");

            migrationBuilder.AlterColumn<int>(
                name: "RankCustomerId",
                table: "promotions",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_promotions_rankCustomer_RankCustomerId",
                table: "promotions",
                column: "RankCustomerId",
                principalTable: "rankCustomer",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_promotions_rankCustomer_RankCustomerId",
                table: "promotions");

            migrationBuilder.AlterColumn<int>(
                name: "RankCustomerId",
                table: "promotions",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.AddColumn<int>(
                name: "RankCustomerld",
                table: "promotions",
                type: "int",
                nullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_promotions_rankCustomer_RankCustomerId",
                table: "promotions",
                column: "RankCustomerId",
                principalTable: "rankCustomer",
                principalColumn: "Id");
        }
    }
}
