﻿namespace Project_Pinterest.Constants
{
    public class AppSettingsKeys
    {
        public const string AUTH_SECRET = "SecretKey";
    }
}
