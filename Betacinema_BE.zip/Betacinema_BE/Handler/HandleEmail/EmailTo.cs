﻿namespace Project_Pinterest.Handler.HandleEmail
{
    public class EmailTo
    {
        public string To { get; set; }
        public string Subject { get; set; }
        public string Content { get; set; }
    }
}
